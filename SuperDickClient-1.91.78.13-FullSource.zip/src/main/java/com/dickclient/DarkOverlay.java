package com.dickclient;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class DarkOverlay implements HudRenderCallback {
    @Override
    public void onHudRender(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        int w = client.getWindow().getScaledWidth();
        int h = client.getWindow().getScaledHeight();
        long now = System.currentTimeMillis();

        if (now < DickClient.darkForceUntil) {
            context.fill(0, 0, w, h, 0xFF000000);
            long remain = (DickClient.darkForceUntil - now) / 1000;
            context.drawCenteredTextWithShadow(client.textRenderer,
                    "锁定 " + (remain / 60) + ":" + String.format("%02d", remain % 60),
                    w / 2, h / 2 - 4, 0xFF5555);
        }

        if (DickClient.yellowFireOverlay) {
            context.fill(0, 0, w, h, 0xAAFFFF00);
        }
    }
}
