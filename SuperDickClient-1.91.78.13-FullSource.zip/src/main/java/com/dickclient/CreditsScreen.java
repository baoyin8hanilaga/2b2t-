package com.dickclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class CreditsScreen extends Screen {
    private final Screen parent;

    public CreditsScreen(Screen parent) {
        super(Text.literal("制作人员"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("返回"), b -> client.setScreen(parent))
                .dimensions(width / 2 - 50, height - 36, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float d) {
        renderBackground(ctx, mx, my, d);
        super.render(ctx, mx, my, d);
        int cx = width / 2, y = height / 2 - 80;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§d§l超级Dick客户端"), cx, y, 0xFFFFFF);
        y += 24;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§f程序制作：早春三月"), cx, y, 0xFFFFFF);
        y += 16;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§f意见提出：铜头疲带"), cx, y, 0xFFFFFF);
        y += 14;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§f意见提出：胶头滴管"), cx, y, 0xFFFFFF);
        y += 14;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§7分析：纯这两个人"), cx, y, 0xAAAAAA);
        y += 14;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§7格绕客 · 产特机批题"), cx, y, 0xAAAAAA);
        y += 20;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§e官方群聊：1108296436"), cx, y, 0xFFFF55);
        y += 16;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§8v1.91.78.13 · Fabric 1.21.1"), cx, y, 0x888888);
    }

    @Override
    public boolean shouldPause() { return false; }
}
