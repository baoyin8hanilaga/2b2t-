package com.dickclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MenuScreen extends Screen {
    public MenuScreen() {
        super(Text.literal("超级Dick客户端"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = 32;
        int w = 180;
        int h = 18;
        int g = 19;

        y = add(cx, y, w, h, g, "杀戮光环", () -> DickClient.killAuraAnti, v -> DickClient.killAuraAnti = v);
        y = add(cx, y, w, h, g, "刀刀暴击", () -> DickClient.antiCrit, v -> DickClient.antiCrit = v);
        y = add(cx, y, w, h, g, "黑暗视觉", () -> DickClient.darkVision, v -> {
            DickClient.darkVision = v;
            if (v) DickClient.darkForceUntil = System.currentTimeMillis() + 300000L;
        });
        y = add(cx, y, w, h, g, "迪克bot", () -> DickClient.dickBot, v -> DickClient.dickBot = v);
        y = add(cx, y, w, h, g, "自动困住", () -> DickClient.autoTrap, v -> DickClient.autoTrap = v);
        y = add(cx, y, w, h, g, "防击退", () -> DickClient.antiKbQuit, v -> DickClient.antiKbQuit = v);
        y = add(cx, y, w, h, g, "自动食物", () -> DickClient.autoFood, v -> DickClient.autoFood = v);
        y = add(cx, y, w, h, g, "艺术品", () -> DickClient.artWork, v -> DickClient.artWork = v);
        y = add(cx, y, w, h, g, "自动切换鞘翅", () -> DickClient.autoElytra, v -> DickClient.autoElytra = v);
        y = add(cx, y, w, h, g, "自动扔药水", () -> DickClient.autoPotion, v -> DickClient.autoPotion = v);
        y = add(cx, y, w, h, g, "pvp贴图优化", () -> DickClient.pvpYellow, v -> DickClient.pvpYellow = v);
        y = add(cx, y, w, h, g, "自动整理背包", () -> DickClient.scrambleInv, v -> DickClient.scrambleInv = v);
        y = add(cx, y, w, h, g, "自动选择工具", () -> DickClient.wrongTool, v -> DickClient.wrongTool = v);
        y = add(cx, y, w, h, g, "聊天优化bot", () -> DickClient.chatCoord, v -> DickClient.chatCoord = v);
        y = add(cx, y, w, h, g, "断尾逃生", () -> DickClient.dropArmorLow, v -> DickClient.dropArmorLow = v);
        y = add(cx, y, w, h, g, "释放剑气", () -> DickClient.dropWeaponAtk, v -> DickClient.dropWeaponAtk = v);
        y = add(cx, y, w, h, g, "轻松搭方块", () -> DickClient.preferBox, v -> DickClient.preferBox = v);
        y = add(cx, y, w, h, g, "自动寻找末地烛", () -> DickClient.endRodHunt, v -> DickClient.endRodHunt = v);
        y = add(cx, y, w, h, g, "反击退", () -> DickClient.antiKbQuit, v -> DickClient.antiKbQuit = v);
        y = add(cx, y, w, h, g, "反仙人掌", () -> DickClient.cactusStrip, v -> DickClient.cactusStrip = v);
        y = add(cx, y, w, h, g, "空中鞘翅加速", () -> DickClient.airDropGear, v -> DickClient.airDropGear = v);
        y = add(cx, y, w, h, g, "反岩浆", () -> DickClient.lavaDropAll, v -> DickClient.lavaDropAll = v);
        y = add(cx, y, w, h, g, "耶稣", () -> DickClient.jesusMode, v -> DickClient.jesusMode = v);
        y = add(cx, y, w, h, g, "防死亡", () -> DickClient.antiDeath, v -> DickClient.antiDeath = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("§c电脑加速"), b -> client.scheduleStop())
                .dimensions(cx - w / 2, height - 42, w, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("制作人员"), b -> client.setScreen(new CreditsScreen(this)))
                .dimensions(cx - w / 2, height - 22, w / 2 - 2, h).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("关闭"), b -> close())
                .dimensions(cx + 2, height - 22, w / 2 - 2, h).build());
    }

    private int add(int cx, int y, int w, int h, int g, String name,
                    java.util.function.BooleanSupplier get,
                    java.util.function.Consumer<Boolean> set) {
        if (y >= 28 && y < height - 50) {
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(name + "  " + (get.getAsBoolean() ? "§a[开]" : "§7[关]")),
                    b -> {
                        boolean n = !get.getAsBoolean();
                        set.accept(n);
                        b.setMessage(Text.literal(name + "  " + (n ? "§a[开]" : "§7[关]")));
                    }).dimensions(cx - w / 2, y, w, h).build());
        }
        return y + g;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float d) {
        renderBackground(ctx, mx, my, d);
        super.render(ctx, mx, my, d);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("§d§l超级Dick客户端 §7v1.91.78.13"), width / 2, 8, 0xFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
