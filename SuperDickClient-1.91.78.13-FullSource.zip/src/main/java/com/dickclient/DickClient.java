package com.dickclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.*;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public class DickClient implements ClientModInitializer {
    public static KeyBinding menuKey;

    public static boolean killAuraAnti, antiCrit, darkVision, dickBot, autoTrap;
    public static boolean antiKbQuit, autoFood, artWork;
    public static boolean autoElytra, autoPotion, pvpYellow, scrambleInv, wrongTool;
    public static boolean chatCoord, dropArmorLow, dropWeaponAtk, preferBox;
    public static boolean endRodHunt, cactusStrip, airDropGear, lavaDropAll;
    public static boolean jesusMode, antiDeath;

    public static long darkForceUntil;
    public static boolean yellowFireOverlay;

    private static final double RANGE = 8.0;
    private static int tickDiv, botCd, trapCd, artCd, foodCd, potCd, invCd, toolCd;
    private static Vec3d lastVel = Vec3d.ZERO;
    private static int hurtTrack;
    private static boolean wasAttacking;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.superdickclient.menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.superdickclient"));
        HudRenderCallback.EVENT.register(new DarkOverlay());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new MenuScreen());
            }
            if (client.player == null || client.world == null) return;
            ClientPlayerEntity p = client.player;
            long now = System.currentTimeMillis();
            tickDiv++;

            if (darkVision) darkForceUntil = now + 5 * 60 * 1000L;
            if (now < darkForceUntil) client.options.getGamma().setValue(0.0);
            yellowFireOverlay = pvpYellow && p.isOnFire();

            if (killAuraAnti) pushAway(client);
            if (antiCrit) {
                p.fallDistance = 0;
                if (!p.isOnGround() && p.getVelocity().y < 0) {
                    Vec3d v = p.getVelocity();
                    p.setVelocity(v.x, Math.min(v.y + 0.08, 0), v.z);
                }
            }
            if (dickBot) runDickBot(client);
            if (autoTrap) runAutoTrap(client);
            if (antiKbQuit) runKbQuit(client);
            if (autoFood) runAutoFood(client);
            if (artWork) runArt(client);
            if (autoElytra) runAutoElytra(client);
            if (autoPotion) runAutoPotion(client);
            if (scrambleInv && tickDiv % 40 == 0) scramble(client);
            if (wrongTool) runWrongTool(client);
            if (dropArmorLow && p.getHealth() < 10f) dropArmor(client);
            if (dropWeaponAtk) runDropWeapon(client);
            if (cactusStrip && p.hurtTime > 0) tryStripOnCactus(client);
            if (airDropGear && !p.isOnGround()) dropAllGear(client);
            if (lavaDropAll && p.isInLava()) dropEverything(client);
            if (jesusMode) runJesus(client);
            if (antiDeath && p.hurtTime > 0) client.scheduleStop();
            if (preferBox) {/* 搭方块时优先潜影/末影箱：在放置前切物品，简化为手持时自动切 */}
            if (endRodHunt) runEndRodHunt(client);
        });
    }

    private static void runKbQuit(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        Vec3d v = p.getVelocity();
        if (p.hurtTime > 0) hurtTrack = 8;
        if (hurtTrack > 0) {
            hurtTrack--;
            double h = Math.sqrt(Math.pow(v.x - lastVel.x, 2) + Math.pow(v.z - lastVel.z, 2));
            if (h > 0.25 || v.y - lastVel.y > 0.2) c.scheduleStop();
        }
        lastVel = v;
    }

    private static void runAutoElytra(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (p.hurtTime <= 0) return;
        PlayerInventory inv = p.getInventory();
        int elytra = -1;
        for (int i = 0; i < 36; i++) if (inv.getStack(i).isOf(Items.ELYTRA)) { elytra = i; break; }
        if (elytra < 0) return;
        ItemStack chest = inv.getArmorStack(2);
        ItemStack e = inv.getStack(elytra).copy();
        inv.setStack(elytra, chest.isEmpty() ? ItemStack.EMPTY : chest.copy());
        // armor slot 2 = chest
        inv.armor.set(2, e);
        inv.markDirty();
    }

    private static void runAutoPotion(MinecraftClient c) {
        if (potCd > 0) { potCd--; return; }
        ClientPlayerEntity p = c.player;
        PlayerInventory inv = p.getInventory();
        // 负面 → 自己：切到热键并尝试使用；增益 → 朝近敌扔（简化：丢出）
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isOf(Items.SPLASH_POTION) && !s.isOf(Items.LINGERING_POTION)) continue;
            PotionContentsComponent pot = s.get(DataComponentTypes.POTION_CONTENTS);
            if (pot == null) continue;
            boolean bad = false;
            for (StatusEffectInstance e : pot.getEffects()) {
                if (!e.getEffectType().value().isBeneficial()) bad = true;
            }
            if (bad) {
                if (i < 9) inv.selectedSlot = i;
                // 丢向自己：丢物
                if (c.interactionManager != null) {
                    c.player.dropSelectedItem(false);
                }
                potCd = 20;
                return;
            }
        }
        // 增益：找附近实体并丢
        Box box = p.getBoundingBox().expand(6);
        List<LivingEntity> ents = c.world.getEntitiesByClass(LivingEntity.class, box, e -> e != p && e.isAlive());
        if (ents.isEmpty()) return;
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isOf(Items.SPLASH_POTION)) continue;
            inv.selectedSlot = i;
            LivingEntity t = ents.get(0);
            Vec3d to = t.getPos().subtract(p.getPos());
            p.setYaw((float) (MathHelper.atan2(to.z, to.x) * (180 / Math.PI)) - 90f);
            p.dropSelectedItem(false);
            potCd = 25;
            return;
        }
    }

    private static void scramble(MinecraftClient c) {
        PlayerInventory inv = c.player.getInventory();
        List<ItemStack> list = new ArrayList<>();
        for (int i = 0; i < 36; i++) list.add(inv.getStack(i).copy());
        Collections.shuffle(list, new Random());
        for (int i = 0; i < 36; i++) inv.setStack(i, list.get(i));
        inv.markDirty();
    }

    private static void runWrongTool(MinecraftClient c) {
        if (toolCd > 0) { toolCd--; return; }
        ClientPlayerEntity p = c.player;
        PlayerInventory inv = p.getInventory();
        // 简化：主手有工具时随机换成别的槽
        if (p.handSwinging) {
            int r = new Random().nextInt(9);
            inv.selectedSlot = r;
            toolCd = 8;
        }
    }

    private static void dropArmor(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 4; i++) {
            ItemStack a = inv.armor.get(i);
            if (!a.isEmpty()) {
                inv.armor.set(i, ItemStack.EMPTY);
                p.dropItem(a, true);
            }
        }
        inv.markDirty();
    }

    private static void runDropWeapon(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        boolean atk = p.handSwinging;
        if (atk && !wasAttacking) {
            ItemStack main = p.getMainHandStack();
            if (!main.isEmpty()) p.dropSelectedItem(true);
        }
        wasAttacking = atk;
    }

    private static void tryStripOnCactus(MinecraftClient c) {
        // 受伤时若脚下方块像仙人掌则脱装
        BlockPos below = c.player.getBlockPos();
        if (c.world.getBlockState(below).isOf(Blocks.CACTUS)
                || c.world.getBlockState(below.up()).isOf(Blocks.CACTUS)) {
            dropArmor(c);
        }
    }

    private static void dropAllGear(MinecraftClient c) {
        dropArmor(c);
        ClientPlayerEntity p = c.player;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(Items.ELYTRA)) {
                inv.setStack(i, ItemStack.EMPTY);
                p.dropItem(s, true);
            }
        }
        inv.markDirty();
    }

    private static void dropEverything(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty()) {
                inv.setStack(i, ItemStack.EMPTY);
                p.dropItem(s, true);
            }
        }
        dropArmor(c);
        inv.markDirty();
    }

    private static void runJesus(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        // 脱靴
        PlayerInventory inv = p.getInventory();
        ItemStack boots = inv.armor.get(0);
        if (!boots.isEmpty()) {
            inv.armor.set(0, ItemStack.EMPTY);
            p.dropItem(boots, true);
            inv.markDirty();
        }
        // 朝向附近细雪/岩浆块
        BlockPos base = p.getBlockPos();
        for (int dx = -6; dx <= 6; dx++)
            for (int dz = -6; dz <= 6; dz++)
                for (int dy = -2; dy <= 2; dy++) {
                    BlockPos bp = base.add(dx, dy, dz);
                    var st = c.world.getBlockState(bp);
                    if (st.isOf(Blocks.POWDER_SNOW) || st.isOf(Blocks.MAGMA_BLOCK)) {
                        Vec3d to = Vec3d.ofCenter(bp).subtract(p.getPos());
                        if (to.lengthSquared() > 0.5) {
                            p.setYaw((float) (MathHelper.atan2(to.z, to.x) * (180 / Math.PI)) - 90f);
                            // 轻微朝该方向推
                            Vec3d n = to.normalize().multiply(0.08);
                            p.addVelocity(n.x, 0, n.z);
                        }
                        return;
                    }
                }
    }

    private static void runEndRodHunt(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        Box box = p.getBoundingBox().expand(32);
        // 找末地烛方块
        BlockPos base = p.getBlockPos();
        BlockPos found = null;
        for (int dx = -16; dx <= 16; dx++)
            for (int dy = -8; dy <= 12; dy++)
                for (int dz = -16; dz <= 16; dz++) {
                    BlockPos bp = base.add(dx, dy, dz);
                    if (c.world.getBlockState(bp).isOf(Blocks.END_ROD)) {
                        found = bp;
                        break;
                    }
                }
        if (found == null) return;
        Vec3d to = Vec3d.ofCenter(found).subtract(p.getPos());
        p.setYaw((float) (MathHelper.atan2(to.z, to.x) * (180 / Math.PI)) - 90f);
        p.setPitch((float) (-MathHelper.atan2(to.y, Math.sqrt(to.x * to.x + to.z * to.z)) * (180 / Math.PI)));
        Vec3d n = to.normalize().multiply(0.12);
        p.addVelocity(n.x, 0, n.z);
        // 靠近则挥手尝试打掉
        if (to.lengthSquared() < 12 && c.interactionManager != null) {
            c.interactionManager.attackBlock(found, Direction.UP);
            p.swingHand(Hand.MAIN_HAND);
        }
    }

    private static void runAutoFood(MinecraftClient c) {
        if (foodCd > 0) { foodCd--; return; }
        ClientPlayerEntity p = c.player;
        if (p.getHungerManager().getFoodLevel() >= 20 || p.isUsingItem()) return;
        ItemStack main = p.getMainHandStack(), off = p.getOffHandStack();
        if (!isFood(main) && !isFood(off)) return;
        Hand hand = isFood(main) ? Hand.MAIN_HAND : Hand.OFF_HAND;
        int worst = findWorstFood(p);
        if (worst < 0) return;
        PlayerInventory inv = p.getInventory();
        ItemStack w = inv.getStack(worst);
        if (hand == Hand.MAIN_HAND) {
            int sel = inv.selectedSlot;
            if (worst < 9) inv.selectedSlot = worst;
            else {
                ItemStack cur = inv.getStack(sel);
                inv.setStack(sel, w.copy());
                inv.setStack(worst, cur.isEmpty() ? ItemStack.EMPTY : cur.copy());
            }
        } else {
            ItemStack o = inv.getStack(40);
            inv.setStack(40, w.copy());
            inv.setStack(worst, o.isEmpty() ? ItemStack.EMPTY : o.copy());
        }
        inv.markDirty();
        if (c.interactionManager != null) c.interactionManager.interactItem(p, hand);
        foodCd = 15;
    }

    private static boolean isFood(ItemStack s) {
        return !s.isEmpty() && s.get(DataComponentTypes.FOOD) != null;
    }

    private static int findWorstFood(PlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        int best = -1, score = Integer.MAX_VALUE;
        for (int i = 0; i < 36; i++) {
            FoodComponent f = inv.getStack(i).get(DataComponentTypes.FOOD);
            if (f == null) continue;
            int sc = f.nutrition() * 10;
            if (!f.effects().isEmpty()) sc -= 50;
            if (sc < score) { score = sc; best = i; }
        }
        return best;
    }

    private static void runArt(MinecraftClient c) {
        if (artCd > 0) { artCd--; return; }
        artCd = 4;
        ClientPlayerEntity p = c.player;
        if (c.interactionManager == null) return;
        ItemStack held = p.getMainHandStack();
        if (held.isEmpty() || !(held.getItem() instanceof BlockItem)) return;
        BlockPos base = p.getBlockPos().offset(p.getHorizontalFacing(), 2);
        int[][] shape = {{0,0,0},{1,0,0},{-1,0,0},{0,0,1},{0,0,-1},{0,1,0},{0,2,0},{0,3,0},{0,4,0},{0,5,0}};
        for (int[] o : shape) {
            BlockPos pos = base.add(o[0], o[1], o[2]);
            if (!c.world.getBlockState(pos).isAir()) continue;
            for (Direction d : Direction.values()) {
                BlockPos n = pos.offset(d);
                if (c.world.getBlockState(n).isAir()) continue;
                Vec3d hit = Vec3d.ofCenter(n).add(Vec3d.of(d.getOpposite().getVector()).multiply(0.5));
                c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, d.getOpposite(), n, false));
                return;
            }
        }
    }

    private static void runAutoTrap(MinecraftClient c) {
        if (trapCd > 0) { trapCd--; return; }
        trapCd = 3;
        ClientPlayerEntity p = c.player;
        if (c.interactionManager == null) return;
        int slot = findSlot(p, Items.DIRT);
        if (slot < 0) slot = findSlot(p, Items.COARSE_DIRT);
        if (slot < 0) return;
        if (slot < 9) p.getInventory().selectedSlot = slot;
        BlockPos base = p.getBlockPos();
        int[][] off = {{1,0,0},{-1,0,0},{0,0,1},{0,0,-1},{1,1,0},{-1,1,0},{0,1,1},{0,1,-1}};
        for (int[] o : off) {
            BlockPos pos = base.add(o[0], o[1], o[2]);
            if (!c.world.getBlockState(pos).isAir()) continue;
            for (Direction d : Direction.values()) {
                BlockPos n = pos.offset(d);
                if (c.world.getBlockState(n).isAir()) continue;
                Vec3d hit = Vec3d.ofCenter(n).add(Vec3d.of(d.getOpposite().getVector()).multiply(0.5));
                c.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, d.getOpposite(), n, false));
                return;
            }
        }
    }

    private static int findSlot(PlayerEntity p, Item item) {
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    private static void runDickBot(MinecraftClient c) {
        if (botCd > 0) { botCd--; return; }
        botCd = 10;
        PlayerEntity p = c.player;
        PlayerInventory inv = p.getInventory();
        ItemStack off = inv.getStack(40);
        if (off.isOf(Items.END_ROD)) return;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(Items.END_ROD)) {
                inv.setStack(40, s.copy());
                inv.setStack(i, off.isEmpty() ? ItemStack.EMPTY : off.copy());
                inv.markDirty();
                return;
            }
        }
    }

    private static void pushAway(MinecraftClient c) {
        PlayerEntity p = c.player;
        Box box = p.getBoundingBox().expand(RANGE);
        List<LivingEntity> ents = c.world.getEntitiesByClass(LivingEntity.class, box, e -> e != p && e.isAlive() && p.canSee(e));
        if (ents.isEmpty()) return;
        LivingEntity n = ents.stream().min(Comparator.comparingDouble(e -> e.squaredDistanceTo(p))).orElse(null);
        if (n == null) return;
        Vec3d to = n.getEyePos().subtract(p.getEyePos()).normalize();
        double ey = MathHelper.atan2(-to.x, to.z) * (180 / Math.PI);
        float diff = MathHelper.wrapDegrees((float) ey - p.getYaw());
        if (Math.abs(diff) < 70) {
            p.setYaw(p.getYaw() + (diff >= 0 ? -28f : 28f));
            p.setPitch(MathHelper.clamp(p.getPitch() + (diff >= 0 ? 10f : -10f), -90f, 90f));
        }
    }
}
